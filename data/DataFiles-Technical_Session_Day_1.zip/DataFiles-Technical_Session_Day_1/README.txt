REMO15
Used RCP 8.5

Model1 = MOHC-HadGEM2-ES
Model2 = MPI-M-MPI-ESM-LR
Model3 = NCC-NorESM1-M


IMDAA
Reanalysis data
Need pre-approval in writing if you are to use commerically.
Governments, NGO, most research can use but will need to cite data.
Make sure you read the release beforehand.
https://rds.ncmrwf.gov.in/pdf/Data_License_Terms_v2.0_Aug2020_NCMRWF.pdf

Citation: S. Indira Rani, Arulalan T., John P. George, E. N. Rajagopal, Richard Renshaw, Adam Maycock, Dale Barker and M. Rajeevan, 2021: IMDAA: High Resolution Satellite-era Reanalysis for the Indian Monsoon Region, Journal of Climate, https://doi.org/10.1175/JCLI-D-20-0412.1
Acknowledgement: Authors gratefully acknowledge NCMRWF, Ministry of Earth Sciences, Government of India, for IMDAA reanalysis. IMDAA reanalysis was produced under the collaboration between UK Met Office, NCMRWF, and IMD with financial support from the Ministry of Earth Sciences, under the National Monsoon Mission programme
